#!/usr/bin/env bash
set -euo pipefail

read -r -p "Enter string: " string
# Use rev if available, fallback to bash loop
if command -v rev >/dev/null 2>&1; then
  echo "$(echo "$string" | rev)"
else
  len=${#string}
  revstr=""
  for ((i=len-1;i>=0;i--)); do
    revstr+="${string:i:1}"
  done
  echo "$revstr"
fi
