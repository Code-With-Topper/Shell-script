#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -lt 1 ]; then
  echo "Usage: $0 num1 [num2 ...]" >&2
  exit 1
fi

max=$1
min=$1
for v in "$@"; do
  if ! [[ "$v" =~ ^-?[0-9]+$ ]]; then
    echo "Error: '$v' not an integer." >&2; exit 1
  fi
  (( v > max )) && max=$v
  (( v < min )) && min=$v
done

echo "Largest of $* is $max"
echo "Smallest of $* is $min"
