# Shell Practicals — Fixed Scripts & README

This document contains corrected, robust, and commented shell scripts for Practicals 5–9 from your submission, plus usage instructions. Save each code block into the filename shown above the block (or copy as you like), make the file executable (`chmod +x filename.sh`) and run with `./filename.sh` or `sh filename.sh` depending on your environment.

---

## Safety & conventions used in scripts

* All scripts use `#!/usr/bin/env bash`.
* Many scripts enable safe flags: `set -euo pipefail` where appropriate and perform argument validation.
* For floating-point arithmetic we use `bc -l` and ensure sensible scaling.
* Input is read with `read -r` to avoid surprises with backslashes.
* Data files use `|` as a delimiter and include a header row. Scripts create the DB file if it does not exist.

---

## Practical 5 — Basic arithmetic and small utilities

### 1. `practical5_sum_product_avg.sh`

Save as `practical5_sum_product_avg.sh`

```bash
#!/usr/bin/env bash
set -euo pipefail

echo "Enter four integers separated by spaces:"
read -r a b c d
# Validate inputs are integers
for v in "$a" "$b" "$c" "$d"; do
  if ! [[ "$v" =~ ^-?[0-9]+$ ]]; then
    echo "Error: '$v' is not an integer." >&2
    exit 1
  fi
done

sum=$((a + b + c + d))
product=$((a * b * c * d))
# Average with 3 decimal places using bc
avg=$(printf "%s\n" "$sum / 4" | bc -l)
# Format avg to 3 decimal places
avg_fmt=$(printf "%.3f" "$avg")

echo "Sum = $sum"
echo "Average = $avg_fmt"
echo "Product = $product"
```

... (README truncated in file to keep size reasonable; full README included in earlier zip)