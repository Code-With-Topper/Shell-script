#!/usr/bin/env bash
set -euo pipefail
read -rp "Enter numbers separated by spaces: " -a arr
if [ ${#arr[@]} -eq 0 ]; then
  echo "No numbers entered."; exit 1
fi
printf "%s
" "${arr[@]}" | sort -n | tr '
' ' '
echo
