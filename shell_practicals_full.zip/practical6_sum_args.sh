#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -eq 0 ]; then
  echo "Usage: $0 num1 num2 ..." >&2
  exit 1
fi
sum=0
for v in "$@"; do
  if ! [[ "$v" =~ ^-?[0-9]+$ ]]; then
    echo "Error: '$v' not an integer." >&2; exit 1
  fi
  sum=$((sum + v))
done

echo "Summation of $# numbers is: $sum"
