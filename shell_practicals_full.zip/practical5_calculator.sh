#!/usr/bin/env bash
set -euo pipefail

while true; do
  clear
  cat <<'MENU'
Simple Calculator
1) Addition
2) Subtraction
3) Multiplication
4) Division
5) Exit
MENU

  read -rp "Enter your choice [1-5]: " choice
  case "$choice" in
    1|2|3|4)
      read -rp "Enter first number: " x
      read -rp "Enter second number: " y
      # Use bc for general math (supports float)
      case "$choice" in
        1) echo "$x + $y = " $(echo "$x + $y" | bc -l) ;;
        2) echo "$x - $y = " $(echo "$x - $y" | bc -l) ;;
        3) echo "$x * $y = " $(echo "$x * $y" | bc -l) ;;
        4)
          if [[ $(echo "$y == 0" | bc -l) -eq 1 ]]; then
            echo "Error: Division by zero.";
          else
            echo "$x / $y = " $(echo "scale=6; $x / $y" | bc -l)
          fi ;;
      esac
      read -rp "Press Enter to continue..." _ ;;
    5) echo "Bye."; exit 0 ;;
    *) echo "Invalid option."; read -rp "Press Enter..." _ ;;
  esac
done
