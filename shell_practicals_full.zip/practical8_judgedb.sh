#!/usr/bin/env bash
set -euo pipefail
DB_FILE="judge_database.txt"
# Initialize DB (header only once)
if [ ! -f "$DB_FILE" ]; then
  echo "JudgeName|CourtName|City|Cases_judged|TotalCases" > "$DB_FILE"
fi

add_record() {
  read -rp "Judge Name: " jname
  read -rp "Court Name: " court
  read -rp "City: " city
  read -rp "Cases judged (integer): " cases
  read -rp "Total cases (integer): " total
  # input checks
  if ! [[ "$cases" =~ ^[0-9]+$ ]] || ! [[ "$total" =~ ^[0-9]+$ ]]; then
    echo "Cases and Total must be integers."; return
  fi
  echo "${jname}|${court}|${city}|${cases}|${total}" >> "$DB_FILE"
  echo "Added."
}

view_records() {
  column -t -s "|" "$DB_FILE"
}

update_record() {
  read -rp "Enter Judge Name to update: " name
  if ! grep -q "^${name}|" "$DB_FILE"; then echo "Not found."; return; fi
  tmp=$(mktemp)
  head -n1 "$DB_FILE" > "$tmp"
  tail -n +2 "$DB_FILE" | while IFS='|' read -r j c city cases total; do
    if [ "$j" = "$name" ]; then
      echo "Current: $j | $c | $city | $cases | $total"
      read -rp "New Court (enter to keep): " nc
      read -rp "New City (enter to keep): " ncity
      read -rp "New Cases judged (enter to keep): " ncases
      read -rp "New Total cases (enter to keep): " ntotal
      nc=${nc:-$c}
      ncity=${ncity:-$city}
      ncases=${ncases:-$cases}
      ntotal=${ntotal:-$total}
      echo "${j}|${nc}|${ncity}|${ncases}|${ntotal}" >> "$tmp"
    else
      echo "${j}|${c}|${city}|${cases}|${total}" >> "$tmp"
    fi
  done
  mv "$tmp" "$DB_FILE"
  echo "Updated."
}

delete_record() {
  read -rp "Enter Judge Name to delete: " name
  if ! grep -q "^${name}|" "$DB_FILE"; then echo "Not found."; return; fi
  tmp=$(mktemp)
  head -n1 "$DB_FILE" > "$tmp"
  grep -v "^${name}|" <(tail -n +2 "$DB_FILE") >> "$tmp"
  mv "$tmp" "$DB_FILE"
  echo "Deleted."
}

count_records(){
  tail -n +2 "$DB_FILE" | sed '/^$/d' | wc -l
}

find_highest(){
  awk -F'|' 'NR>1{ if($4+0 > mx){mx=$4; name=$1}} END{ if(mx=="") print "No data"; else print name" ("mx")" }' "$DB_FILE"
}

ahmedabad_total(){
  awk -F'|' 'BEGIN{sum=0} NR>1{ if(tolower($3)=="ahmedabad") sum+=($5+0)} END{print sum}' "$DB_FILE"
}

list_judges(){
  tail -n +2 "$DB_FILE" | cut -d'|' -f1 | sort
}

while true; do
  cat <<'MENU'

Judge DB Menu
1) Add
2) Update
3) View
4) Delete
5) Display count
6) Judge with highest cases judged
7) Total cases (Ahmedabad)
8) List judge names
9) Exit
MENU
  read -rp "Choice: " ch
  case "$ch" in
    1) add_record ;;
    2) update_record ;;
    3) view_records ;;
    4) delete_record ;;
    5) echo "Count: $(count_records)" ;;
    6) find_highest ;;
    7) ahmedabad_total ;;
    8) list_judges ;;
    9) exit 0 ;;
    *) echo "Invalid" ;;
  esac
  read -rp "Press Enter to continue..." _
  clear
done
