#!/usr/bin/env bash
set -euo pipefail
read -rp "Enter a character: " c
if [ ${#c} -ne 1 ]; then
  echo "Please enter exactly one character."; exit 1
fi
case "$c" in
  [A-Z]) echo "Uppercase letter" ;;
  [a-z]) echo "Lowercase letter" ;;
  [0-9]) echo "Digit" ;;
  *) echo "Other character" ;;
esac
