#!/usr/bin/env bash
set -euo pipefail
read -rp "Enter filename: " f
if [ ! -e "$f" ]; then
  echo "File does not exist."; exit 1
fi
if [ -f "$f" ]; then
  echo "'$f' is an ordinary (regular) file."
else
  echo "'$f' is NOT an ordinary file."
fi
