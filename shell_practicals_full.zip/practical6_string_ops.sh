#!/usr/bin/env bash
set -euo pipefail

read -rp "Enter the string: " s
read -rp "Enter substring start index (0-based): " start
read -rp "Enter substring length: " length
read -rp "Enter a character to find: " ch

# length
echo "Length: ${#s}"
# substring
substr=${s:start:length}
echo "Substring: '$substr'"
# location (1-based) using expr index; 0 if not found
pos=$(expr index "$s" "$ch")
if [ "$pos" -eq 0 ]; then
  echo "Character '$ch' not found"
else
  echo "Character '$ch' first occurs at position $pos (1-based)"
fi
