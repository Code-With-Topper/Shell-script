#!/usr/bin/env bash
set -euo pipefail

echo "Enter four integers separated by spaces:"
read -r a b c d
# Validate inputs are integers
for v in "$a" "$b" "$c" "$d"; do
  if ! [[ "$v" =~ ^-?[0-9]+$ ]]; then
    echo "Error: '$v' is not an integer." >&2
    exit 1
  fi
done

sum=$((a + b + c + d))
product=$((a * b * c * d))
# Average with 3 decimal places using bc
avg=$(printf "%s
" "$sum / 4" | bc -l)
# Format avg to 3 decimal places
avg_fmt=$(printf "%.3f" "$avg")

echo "Sum = $sum"
echo "Average = $avg_fmt"
echo "Product = $product"
