#!/usr/bin/env bash
set -euo pipefail

read -rp "Enter Basic salary: " basic
if ! [[ "$basic" =~ ^[0-9]+(\.[0-9]+)?$ ]]; then
  echo "Error: invalid salary." >&2
  exit 1
fi

# Percentages
da=$(echo "scale=2; $basic * 10 / 100" | bc -l)
hra=$(echo "scale=2; $basic * 20 / 100" | bc -l)
# gross
gross=$(echo "scale=2; $basic + $da + $hra" | bc -l)

echo "DA = $da"
echo "HRA = $hra"
echo "Gross salary = $gross"
