#!/usr/bin/env bash
set -euo pipefail
DB_FILE="library.db"
[ -f "$DB_FILE" ] || touch "$DB_FILE"

while true; do
  cat <<'MENU'
Library Menu
1) View (search)
2) Add
3) Delete (by AccNo)
4) Count
5) Exit
MENU
  read -rp "Choice: " c
  case "$c" in
    1)
      read -rp "Search term (AccNo/Title/Author): " q
      grep -i -- "$q" "$DB_FILE" || echo "No matches"
      ;;
    2)
      read -rp "AccNo: " acc
      if grep -q "^${acc}|" "$DB_FILE"; then echo "AccNo exists"; else
        read -rp "Title: " title
        read -rp "Author: " author
        read -rp "Edition: " edition
        read -rp "Publisher: " pub
        echo "${acc}|${title}|${author}|${edition}|${pub}" >> "$DB_FILE"
        echo "Added"
      fi
      ;;
    3)
      read -rp "AccNo to delete: " acc
      if grep -q "^${acc}|" "$DB_FILE"; then
        grep -v "^${acc}|" "$DB_FILE" > tmp && mv tmp "$DB_FILE"
        echo "Deleted"
      else
        echo "Not found"
      fi
      ;;
    4)
      wc -l < "$DB_FILE" | awk '{print $1 " records"}' ;;
    5) exit 0 ;;
    *) echo "Invalid" ;;
  esac
  read -rp "Press Enter to continue..." _
  clear
done
