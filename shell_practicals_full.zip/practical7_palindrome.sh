#!/usr/bin/env bash
set -euo pipefail
read -rp "Enter string: " s
rev=$(echo "$s" | rev)
if [[ "$s" == "$rev" ]]; then
  echo "'$s' is a palindrome."
else
  echo "'$s' is not a palindrome."
fi
