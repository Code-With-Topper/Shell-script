#!/usr/bin/env bash
set -euo pipefail

read -rp "Enter value of x (number): " x
# compute using bc
sum=0
for i in {0..4}; do
  term=$(echo "scale=6; $x ^ $i" | bc -l)
  sum=$(echo "scale=6; $sum + $term" | bc -l)
done

printf "Sum = %.6f
" "$sum"
