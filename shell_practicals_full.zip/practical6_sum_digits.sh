#!/usr/bin/env bash
set -euo pipefail

read -rp "Enter a non-negative integer: " n
if ! [[ "$n" =~ ^[0-9]+$ ]]; then
  echo "Error: enter a non-negative integer." >&2; exit 1
fi
sum=0
orig=$n
while [ "$n" -gt 0 ]; do
  digit=$((n % 10))
  sum=$((sum + digit))
  n=$((n / 10))
done

echo "Sum of digits of $orig is $sum"
