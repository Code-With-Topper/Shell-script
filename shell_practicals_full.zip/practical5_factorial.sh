#!/usr/bin/env bash
set -euo pipefail

read -rp "Enter a non-negative integer to compute factorial: " n
if ! [[ "$n" =~ ^[0-9]+$ ]]; then
  echo "Error: please enter a non-negative integer." >&2
  exit 1
fi

result=1
for ((i=2;i<=n;i++)); do
  result=$((result * i))
done

echo "Factorial of $n is $result"
